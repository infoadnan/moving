# Italia Transit

Free transit journey planner for Italy. Frontend only: uses the public Transitous API (api.transitous.org), no server needed.

## Easiest deploy (single file)
1. Open `index.html` (the built single file) in a text editor and change `your-email@example.com` to your real email/website.
2. GitHub -> New repository -> Add file -> Upload files -> upload ONLY `index.html` -> Commit.
3. Settings -> Pages -> Source: Deploy from a branch -> `main` / `(root)` -> Save.
4. Open https://USERNAME.github.io/REPO/ after ~1 minute.

## Edit the source
npm install && npm run dev
npm run build  -> dist/index.html (single file, upload this)

Usage policy: Transitous is for open-source, non-commercial, light use. Keep the visible contact info and the Transitous/sources link.
