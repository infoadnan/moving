import { useEffect, useRef, useState } from 'react'
import { geocode } from './api.js'

export default function PlaceInput({ label, value, onPick, bias, extra }) {
  const [text, setText] = useState(value?.name || '')
  const [options, setOptions] = useState([])
  const picked = useRef(value?.name || '')

  useEffect(() => { setText(value?.name || ''); picked.current = value?.name || '' }, [value])

  useEffect(() => {
    if (text.length < 2 || text === picked.current) { setOptions([]); return }
    const t = setTimeout(() => geocode(text, bias()).then(setOptions).catch(() => setOptions([])), 350)
    return () => clearTimeout(t)
  }, [text])

  return (
    <div className="field">
      <label>{label}</label>
      <div className="row">
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Stop, street or place" />
        {extra}
      </div>
      {options.length > 0 && (
        <ul className="options">
          {options.map((o, i) => (
            <li key={i}>
              <button onClick={() => { picked.current = o.name; onPick(o); setOptions([]) }}>
                <span>{o.name}</span>
                <small>{o.type === 'STOP' ? 'Stop' : o.type === 'ADDRESS' ? 'Address' : 'Place'}{o.detail ? ` · ${o.detail}` : ''}</small>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
