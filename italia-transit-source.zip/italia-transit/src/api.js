const BASE = 'https://api.transitous.org'

async function get(path, params, versions) {
  let err
  for (const v of versions) {
    const url = new URL(`${BASE}/api/${v}/${path}`)
    Object.entries(params).forEach(([k, val]) => val != null && url.searchParams.set(k, val))
    const res = await fetch(url)
    if (res.ok) return res.json()
    err = new Error(`Transitous error ${res.status}`)
    if (res.status !== 404) break
  }
  throw err
}

// Routing. Tries v5, then v6 if v5 is gone.
export async function planTrip(from, to) {
  const data = await get('plan', {
    fromPlace: `${from.lat},${from.lon}`,
    toPlace: `${to.lat},${to.lon}`,
    numItineraries: 5,
  }, ['v5', 'v6'])
  return data.itineraries || []
}

// Place / stop search
export async function geocode(text, bias) {
  const data = await get('geocode', {
    text, language: 'it',
    place: bias ? `${bias.lat},${bias.lon}` : null,
  }, ['v1'])
  return data.slice(0, 6).map((m) => ({
    id: m.type === 'STOP' ? m.id : null,
    type: m.type,
    name: m.name,
    detail: (m.areas || []).find((a) => a.default)?.name || '',
    lat: m.lat,
    lon: m.lon,
  }))
}

// Next departures at a stop
export async function stopTimes(stopId) {
  const data = await get('stoptimes', { stopId, n: 8 }, ['v5', 'v6'])
  return (data.stopTimes || []).map((s) => ({
    mode: s.mode,
    line: s.displayName || s.routeShortName || s.mode,
    headsign: s.headsign || s.tripTo?.name || '',
    time: s.place?.departure || s.place?.scheduledDeparture,
    live: !!s.realTime,
    color: s.routeColor,
  }))
}

// Google encoded polyline -> [[lon, lat], ...]. MOTIS v2+ uses precision 6.
export function decodePolyline(str, precision = 6) {
  const f = 10 ** precision
  let i = 0, lat = 0, lon = 0
  const out = []
  while (i < str.length) {
    for (const axis of [0, 1]) {
      let shift = 0, result = 0, b
      do { b = str.charCodeAt(i++) - 63; result |= (b & 31) << shift; shift += 5 } while (b >= 32)
      const d = result & 1 ? ~(result >> 1) : result >> 1
      if (axis === 0) lat += d; else lon += d
    }
    out.push([lon / f, lat / f])
  }
  return out
}
