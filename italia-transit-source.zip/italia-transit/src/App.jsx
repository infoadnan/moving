import { useEffect, useRef, useState } from 'react'
import maplibregl from 'maplibre-gl'
import PlaceInput from './PlaceInput.jsx'
import { planTrip, stopTimes, decodePolyline } from './api.js'

const CITIES = [
  ['Rome', 12.4964, 41.9028], ['Milan', 9.19, 45.4642], ['Naples', 14.2681, 40.8518],
  ['Turin', 7.6869, 45.0703], ['Genoa', 8.9463, 44.4056], ['Catania', 15.087, 37.5079],
]
const MODE_COLORS = { BUS: '#4c8dff', TRAM: '#ff9f43', SUBWAY: '#ff5d73', SUBURBAN: '#ff5d73',
  FERRY: '#27c5d6', FUNICULAR: '#9b7bff', WALK: '#9aa8a0' }
const modeColor = (m, c) => (c ? `#${c.replace('#', '')}` : MODE_COLORS[m] || (m?.includes('RAIL') ? '#e5484d' : '#4c8dff'))
const fmt = (iso) => (iso ? new Date(iso).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }) : '--:--')
const mins = (s) => Math.max(1, Math.round(s / 60))
const contact = window.APP_CONFIG?.contact || ''

const STYLE = {
  version: 8,
  sources: { carto: { type: 'raster', tileSize: 256, maxzoom: 19,
    attribution: '© OpenStreetMap contributors © CARTO',
    tiles: ['a', 'b', 'c', 'd'].map((s) => `https://${s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png`) } },
  layers: [{ id: 'carto', type: 'raster', source: 'carto' }],
}

export default function App() {
  const mapEl = useRef(null)
  const map = useRef(null)
  const markers = useRef({})
  const [from, setFrom] = useState(null)
  const [to, setTo] = useState(null)
  const [trips, setTrips] = useState([])
  const [active, setActive] = useState(0)
  const [status, setStatus] = useState('idle')
  const [error, setError] = useState('')
  const [deps, setDeps] = useState(null)

  useEffect(() => {
    const m = new maplibregl.Map({ container: mapEl.current, style: STYLE, center: [12.4964, 41.9028], zoom: 11, attributionControl: { compact: true } })
    m.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right')
    m.on('load', () => {
      m.addSource('route', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } })
      m.addLayer({ id: 'route-transit', type: 'line', source: 'route', filter: ['!=', ['get', 'mode'], 'WALK'],
        layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': ['get', 'color'], 'line-width': 6 } })
      m.addLayer({ id: 'route-walk', type: 'line', source: 'route', filter: ['==', ['get', 'mode'], 'WALK'],
        paint: { 'line-color': ['get', 'color'], 'line-width': 4, 'line-dasharray': [1, 1.6] } })
    })
    m.on('click', (e) => {
      const p = { name: `${e.lngLat.lat.toFixed(4)}, ${e.lngLat.lng.toFixed(4)}`, lat: e.lngLat.lat, lon: e.lngLat.lng }
      setFrom((f) => (f ? (setTo(p), f) : p))
    })
    map.current = m
    return () => m.remove()
  }, [])

  useEffect(() => {
    const set = (key, p, col) => {
      markers.current[key]?.remove()
      if (!p || !map.current) return
      markers.current[key] = new maplibregl.Marker({ color: col }).setLngLat([p.lon, p.lat]).addTo(map.current)
    }
    set('from', from, '#3ddc97')
    set('to', to, '#ff5d73')
  }, [from, to])

  useEffect(() => {
    setDeps(null)
    if (!from?.id) return
    stopTimes(from.id).then(setDeps).catch(() => setDeps([]))
  }, [from])

  useEffect(() => {
    const m = map.current
    if (!m || !m.getSource('route')) return
    const trip = trips[active]
    const features = trip ? trip.legs.map((l) => ({
      type: 'Feature',
      properties: { mode: l.mode, color: modeColor(l.mode, l.routeColor) },
      geometry: { type: 'LineString', coordinates: decodePolyline(l.legGeometry.points, l.legGeometry.precision ?? 6) },
    })) : []
    m.getSource('route').setData({ type: 'FeatureCollection', features })
    if (features.length) {
      const b = new maplibregl.LngLatBounds()
      features.forEach((f) => f.geometry.coordinates.forEach((c) => b.extend(c)))
      m.fitBounds(b, { padding: { top: 80, bottom: 280, left: 50, right: 50 }, maxZoom: 16 })
    }
  }, [trips, active])

  async function search() {
    if (!from || !to) return
    setStatus('loading'); setError('')
    try {
      const r = await planTrip(from, to)
      setTrips(r); setActive(0)
      if (!r.length) { setStatus('error'); setError('No route found. Try other points or check both are in a covered city.') }
      else setStatus('idle')
    } catch (e) { setStatus('error'); setError(e.message) }
  }

  function locate() {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const p = { name: 'My location', lat: pos.coords.latitude, lon: pos.coords.longitude }
        setFrom(p); map.current.flyTo({ center: [p.lon, p.lat], zoom: 14 })
      },
      () => { setStatus('error'); setError('Location blocked. Allow location access in your browser.') }
    )
  }

  function clear() { setFrom(null); setTo(null); setTrips([]); setStatus('idle'); setError('') }
  const bias = () => { const c = map.current.getCenter(); return { lat: c.lat, lon: c.lng } }

  return (
    <div className="app">
      <div ref={mapEl} className="map" />
      <aside className="panel">
        <div className="head">
          <h1>Italia Transit</h1>
          <button className="link" onClick={clear}>Clear</button>
        </div>
        <div className="chips">
          {CITIES.map(([n, x, y]) => (
            <button key={n} className="city" onClick={() => map.current.flyTo({ center: [x, y], zoom: 12 })}>{n}</button>
          ))}
        </div>
        <PlaceInput label="From" value={from} onPick={setFrom} bias={bias}
          extra={<button className="ghost" onClick={locate} title="Use my location">GPS</button>} />
        <PlaceInput label="To" value={to} onPick={setTo} bias={bias}
          extra={<button className="ghost" onClick={() => { setFrom(to); setTo(from) }} title="Swap">⇅</button>} />
        <button className="primary" onClick={search} disabled={!from || !to || status === 'loading'}>
          {status === 'loading' ? 'Searching…' : 'Find route'}
        </button>
        <p className="hint">Or tap the map: first tap sets From, second sets To.</p>
        {status === 'error' && <p className="error">{error}</p>}

        <ol className="trips">
          {trips.map((t, i) => (
            <li key={i}>
              <button className={i === active ? 'trip active' : 'trip'} onClick={() => setActive(i)}>
                <div className="trip-top">
                  <strong>{fmt(t.startTime)} – {fmt(t.endTime)}</strong>
                  <span>{mins(t.duration)} min</span>
                </div>
                <div className="legs">
                  {t.legs.map((l, j) => (
                    <span key={j} className="chip" style={{ background: modeColor(l.mode, l.routeColor) }}>
                      {l.mode === 'WALK' ? `${mins(l.duration)}′ walk` : (l.displayName || l.routeShortName || l.mode)}
                      {l.realTime && l.mode !== 'WALK' ? ' ●' : ''}
                    </span>
                  ))}
                </div>
                <small>{t.transfers} transfer{t.transfers === 1 ? '' : 's'}</small>
              </button>
            </li>
          ))}
        </ol>

        {deps && deps.length > 0 && (
          <section className="deps">
            <h2>Next departures · {from.name}</h2>
            <ul>
              {deps.map((d, i) => (
                <li key={i}>
                  <span className="chip" style={{ background: modeColor(d.mode, d.color) }}>{d.line}</span>
                  <span className="dest">{d.headsign}</span>
                  <b>{fmt(d.time)}{d.live ? ' ●' : ''}</b>
                </li>
              ))}
            </ul>
          </section>
        )}

        <footer>
          <small>● = live data. Data: <a href="https://transitous.org" target="_blank" rel="noreferrer">Transitous</a> (<a href="https://transitous.org/sources" target="_blank" rel="noreferrer">sources</a>) · © OpenStreetMap · © CARTO{contact ? ` · Contact: ${contact}` : ''}</small>
        </footer>
      </aside>
    </div>
  )
}
